dbHelper -> Database
itemScreen -> item card
myProvider -> Provider class
screen -> Main_screen
shoppingList -> State class ShoppingList
shoppingListDialog -> Dialog

(main.dart)

Latihan no 1 :
(img) & SharedPrereference di Provider

Latihan no 2:
(img) & deleteAll() in Provider and dbHelper

Latihan no 3:
listHistory.dart
(some code related with History)
Provider, dbHelper, screenHistory & listHistory State